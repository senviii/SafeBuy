# SafeBuy – Shop Smart, Shop Safe

SafeBuy is a Chrome extension built during **AMUHACKS 4.0** to help users shop safely online. It scans websites in real time to flag suspicious sellers, detect phishing attempts, and warn users before they get scammed.

## Features
- 🔍 Clone site + phishing detection
- 🛒 Seller legitimacy analysis
- ✅ Trust Score badge (Green, Yellow, Red)
- 📢 Community reports
- 🧠 ML-powered scam pattern spotting

## How to Use
1. Clone/download the repo
2. Go to `chrome://extensions`
3. Enable Developer Mode → Load Unpacked → Select this folder
4. Start browsing safer.

Made with 💙 by Saanvi Mahika
