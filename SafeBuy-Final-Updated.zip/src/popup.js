// Simple popup logic for SafeBuy
document.addEventListener('DOMContentLoaded', () => {
  const status = document.getElementById('status');
  status.textContent = "Analyzing this website...";
  // TODO: Hook into phishing and fake-shop detection
});
